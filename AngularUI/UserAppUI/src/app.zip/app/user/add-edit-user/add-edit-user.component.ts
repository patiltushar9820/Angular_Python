import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-user',
  templateUrl: './add-edit-user.component.html',
  styleUrls: ['./add-edit-user.component.css']
})
export class AddEditUserComponent implements OnInit {

  isLinear = false;
  first1FormGroup: FormGroup;
  registrationForm: FormGroup;
  secondFormGroup: FormGroup;

  @Input() regForm: FormGroup;
  user_id_update:string

  UserListEdit:Array<Object>=[]
  public UserListRead:Array<Object>=[]

 

  constructor(private sharedservice:SharedService,
    private route: ActivatedRoute,
    private _formBuilder: FormBuilder) { }


  ngOnInit(): void {

 // get user id for user data update
 this.user_id_update= this.route.snapshot.params['data'];
 console.log("user id for update :",this.user_id_update)

 this.sharedservice.getParticularUserData(this.user_id_update).subscribe(data=>{
  this.UserListEdit=data;
  console.log("user data particular:",this.UserListEdit);
  for(let i of this.UserListEdit){
  //console.log("key out for ",i["UserId"])
  if(i["UserId"] == this.user_id_update) {
   console.log("key ",i["F_Name"] )

   this.UserListRead.push(i)
   console.log("push data",this.UserListRead)
   
  }
  }
  
})
  

  if(this.user_id_update==="adduser"){

    this.registrationForm = new FormGroup({
      'personalDetails': new FormGroup({
        'F_Name': new FormControl(null, Validators.required),
        'M_Name': new FormControl(null,Validators.required),
        'L_Name': new FormControl(null, Validators.required),
        'Date_Of_Birth': new FormControl(null, Validators.required),
        'U_Email': new FormControl(null, [Validators.required,Validators.email]),
        'Ph_Number': new FormControl(null, Validators.required),

        
        
      }),
      'addrDetails': new FormGroup({
        'Addr_City': new FormControl(null, [Validators.required]),
        'Addr_State': new FormControl(null, [Validators.required]),
        'Addr_Zip': new FormControl(null, [Validators.required]),
        'U_Created_On': new FormControl(null, [Validators.required])
      })
     
    });
  } else {

    
    

    this.registrationForm = new FormGroup({
      'personalDetails': new FormGroup({
        'F_Name': new FormControl(null, Validators.required),
        'M_Name': new FormControl(null,Validators.required),
        'L_Name': new FormControl(null, Validators.required),
        'Date_Of_Birth': new FormControl(null, Validators.required),
        'U_Email': new FormControl(null, [Validators.required,Validators.email]),
        'Ph_Number': new FormControl(null, Validators.required),
        
      }),
      'addrDetails': new FormGroup({
        'Addr_City': new FormControl(null, [Validators.required]),
        'Addr_State': new FormControl(null, [Validators.required]),
        'Addr_Zip': new FormControl(null, [Validators.required]),
        'U_Created_On': new FormControl(null, [Validators.required])
      })
    


    });
    

  }

   
   

   
  }

}
