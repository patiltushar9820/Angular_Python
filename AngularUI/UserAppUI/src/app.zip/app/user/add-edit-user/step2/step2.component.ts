import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-step2',
  templateUrl: './step2.component.html',
  styleUrls: ['./step2.component.css']
})
export class Step2Component implements OnInit {

  constructor() { }

  @Input() regForm: FormGroup;

  ngOnInit(): void {
  }

  step2Submitted() {
    this.regForm.get('addrDetails').get('Addr_City').markAsTouched();
    this.regForm.get('addrDetails').get('Addr_City').updateValueAndValidity();

    this.regForm.get('addrDetails').get('Addr_State').markAsTouched();
    this.regForm.get('addrDetails').get('Addr_State').updateValueAndValidity();

    this.regForm.get('addrDetails').get('Addr_Zip').markAsTouched();
    this.regForm.get('addrDetails').get('Addr_Zip').updateValueAndValidity();

    this.regForm.get('addrDetails').get('U_Created_On').markAsTouched();
    this.regForm.get('addrDetails').get('U_Created_On').updateValueAndValidity();
  }
}
