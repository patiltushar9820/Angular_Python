import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-step3',
  templateUrl: './step3.component.html',
  styleUrls: ['./step3.component.css']
})
export class Step3Component implements OnInit {
  Dataa: Array<string>=new Array;
  
  userinput:string

  constructor(private sharedservice:SharedService ) { }

  @Input() regForm: FormGroup;
  formSubmitted: boolean = false;

 

  ngOnInit(): void {

   
  }

  submit() {
 
    console.log('submitted');
    console.log(this.regForm.value.personalDetails );
    this.formSubmitted = true;

   
    //this.Dataa=Object.values(this.regForm)
    //const Dataa=Object.assign({},this.regForm["personalDetails"],this.regForm["addrDetails"])
   this.Dataa.push(this.regForm.value.personalDetails)
   this.Dataa.push(this.regForm.value.addrDetails)
   
   
/*
    var val ={
    'UserId':1,
    'F_Name':this.regForm.value.personalDetails.F_Name,
    'M_Name':this.regForm.value.personalDetails.M_Name,
    'L_Name':this.regForm.value.personalDetails.L_Name,
    'Date_Of_Birth':this.regForm.value.personalDetails.Date_Of_Birth,
    'U_Email':this.regForm.value.personalDetails.U_Email,
    'Ph_Number':this.regForm.value.personalDetails.Ph_Number,
    'Addr_City':this.regForm.value.addrDetails.Addr_City,
    'Addr_State':this.regForm.value.addrDetails.Addr_State,
    'Addr_Zip':this.regForm.value.addrDetails.Addr_Zip,
    'U_Created_On':this.regForm.value.addrDetails.U_Created_On
   }*/
  
  this.postUserdata()
  }

  postUserdata(){
    var phnumber=Number(this.regForm.value.personalDetails.Ph_Number)
    console.log("no ",phnumber)
    var val ={
      "UserId":5,
      "F_Name":this.regForm.value.personalDetails.F_Name,
      "M_Name":this.regForm.value.personalDetails.M_Name,
      "L_Name":this.regForm.value.personalDetails.L_Name,
      "Date_Of_Birth":this.regForm.value.personalDetails.Date_Of_Birth,
      "U_Email":this.regForm.value.personalDetails.U_Email,
      "Ph_Number":Number(phnumber),
      "Addr_City":this.regForm.value.addrDetails.Addr_City,
      "Addr_State":this.regForm.value.addrDetails.Addr_State,
      "Addr_Zip":this.regForm.value.addrDetails.Addr_Zip,
      "U_Created_On":this.regForm.value.addrDetails.U_Created_On
     }
    /* var val ={
      "UserId":1,
      "F_Name":"tushar",
      "M_Name":"suresh",
      "L_Name":"patil",
      "Date_Of_Birth":"1998-02-02",
      "U_Email":"patil@gmail.com",
      "Ph_Number":9325932898,
      "Addr_City":"nashik",
      "Addr_State":"mh",
      "Addr_Zip":"423104",
      "U_Created_On":"2020-03-03"
     }
     */
     console.log("json",val)
    
    this.sharedservice.addUserData(val).subscribe(data=> {
      this.userinput=data.toString();
     alert(this.userinput);
     /* for(let i of this.UserList) {
        console.log("First name :",i["F_Name"]);
      }
      */
    })
  }

}
