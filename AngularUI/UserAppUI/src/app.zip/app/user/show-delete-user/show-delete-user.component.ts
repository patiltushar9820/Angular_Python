import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

import { DataSource } from '@angular/cdk/collections';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-delete-user',
  templateUrl: './show-delete-user.component.html',
  styleUrls: ['./show-delete-user.component.css']
})
export class ShowDeleteUserComponent implements OnInit {

  constructor(private sharedservice:SharedService,
    private router:Router) { }

  UserList:Array<Object>=[];

  user_id_update:string;

  displayedColumns: string[] = ['F_Name', 'U_Created_On','U_Email','Addr_State','Action'];

  ngOnInit(): void {
    this.getUserdata();
  }

  //read user data
  getUserdata(){
    this.sharedservice.getUserData().subscribe(data=>{
      this.UserList=data;
      console.log("user data :",this.UserList);
     /* for(let i of this.UserList) {
        console.log("First name :",i["F_Name"]);
      }
      */
    })
  }


  //add new user data
  addUserdata() {
    this.router.navigate(['user/adduser/'])
  }

  //update user data
  updateUserdata(u_id) {
    this.user_id_update=u_id.UserId
    if(this.user_id_update!==undefined) {
      this.router.navigate(['user',this.user_id_update])
    }
  }


  //delete user data
  deleteUserdata(u_id) {
    if(confirm('Are You Sure To Delete It ??')) {
      this.sharedservice.deleteUserData(u_id.UserId).subscribe(data=> {
        alert(data.toString())
      })
    }
  }

}
